def spotify_playlists():
    playlists = {'rap_caviar': 'spotify:playlist:37i9dQZF1DX0XUsuxWHRQd'}
    return playlists


def personal_playlists():
    playlists = {'drive_hood': 'spotify:playlist:1uM1laLmdeCMRQoYC1gybB'}
    return playlists
