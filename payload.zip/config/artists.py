def spotify_artists():
    artists = {'Kanye West': 'spotify:artist:5K4W6rqBFWDnAN6FQUkS6x',
               'Drake': 'spotify:artist:3TVXtAsR1Inumwj472S9r4',
               'Kota The Friend': 'spotify:artist:2AfU5LYBVCiCtuCCfM7uVX',
               'Denzel Curry': 'spotify:artist:6fxyWrfmjcbj5d12gXeiNV'}
    return artists
